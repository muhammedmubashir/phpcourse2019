// this entry is built and wrapped with a factory function
// used to generate a fresh copy of Vue for every Weex instance.

import Vue from './runtime/index'

exports.Vue = Vue
